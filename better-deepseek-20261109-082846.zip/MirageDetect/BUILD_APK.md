# Getting an installable APK from this project

You have two paths. Pick whichever fits your situation.

---

## Path 1 — Cloud build (recommended, no local setup)

GitHub builds the APK for you on their servers. You need a GitHub account and nothing else.

### 1. Push the project to GitHub

Create a new repository on github.com. From your unzipped project folder:

```
cd MirageDetect
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/mirage-detect.git
git push -u origin main
```

> **Important:** the `.github/workflows/build-apk.yml` file must be pushed too. If `.gitignore` or a global gitignore hides `.github/`, force-add it: `git add -f .github`.

### 2. Watch the build

Open the repo on github.com → **Actions** tab → **Build APK** → the run that started automatically.

Or trigger it manually: **Actions → Build APK → Run workflow**.

First run takes ~3–5 minutes. Subsequent runs are faster thanks to Gradle caching.

### 3. Download the APK

Open the completed run → scroll to **Artifacts** → click **app-debug-apk**. A ZIP downloads containing `app-debug.apk`.

### 4. Install it

- **On a phone:** copy `app-debug.apk` to the device (AirDrop, USB, Google Drive, email), tap it, allow "install unknown apps" for whatever app you used to open it.
- **Via adb:** `adb install app-debug.apk`

First launch: grant camera permission → the app downloads the ~4 MB detection model → the overlay appears.

### If the build fails

The workflow uploads the full Gradle log. Common first-run failures:

| Error ↕▾ | Cause ↕▾ | Fix ↕▾ |
|---|---|---|
| −`Could not find settings.gradle.kts` | The repo doesn't contain the project | Ensure `settings.gradle.kts` and `app/` are at the repo root or under `MirageDetect/` |
| −`Minimum supported Gradle version is 8.9` | The workflow's `gradle-version` input was overridden | Keep it at `'8.9'` |
| `Unresolved reference: …` in the build log | A source defect | Read the reported file/line, fix, push again |
| `AAPT2 error: resource mipmap/ic_launcher not found` | Missing launcher fallback | Confirm `app/src/main/res/mipmap-anydpi/ic_launcher.xml` exists |
⚙

---

## Path 2 — Local build (needs Android Studio + JDK 17)

Use this if you want to iterate on the code.

### Prerequisites

- **Android Studio** (Ladybug 2024.2.1 or newer)
- **JDK 17** — Android Studio bundles one
- **Android SDK platform 35** — installed by Android Studio's SDK Manager

### Steps

1. **Open the project.** Android Studio → **File → Open** → select the `MirageDetect/` folder.
2. **Generate the Gradle wrapper.** The binary `gradle-wrapper.jar` can't be shipped in a text ZIP. Either:

- Accept Android Studio's prompt to use a bundled Gradle distribution, **or**
- Run from a terminal with Gradle 8.9+ installed: `gradle wrapper --gradle-version 8.9`
3. **Confirm JDK 17.** **File → Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle JDK** → 17.
4. **Sync.** **File → Sync Project with Gradle Files**.
5. **Run.** Pick an emulator (API 35) or a USB device from the toolbar dropdown, click **Run ▶**.

### Produce the APK file

```
# Windows
gradlew.bat assembleDebug

# macOS / Linux
./gradlew assembleDebug
```

Output:

```
app/build/outputs/apk/debug/app-debug.apk
```

Install it directly:

```
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## What changed in this build (from the research report)

Four source-level fixes were applied so the project builds cleanly:

| File ↕▾ | Change ↕▾ |
|---|---|
| −`ui/components/EngineChip.kt` | Removed two duplicate `Modifier.width` extension functions (a hard Kotlin redeclaration error). Replaced FQN calls with proper imports. |
| `ui/components/DetectTopBar.kt` | Removed a local `Box() = Unit` stub that shadowed the layout `Box`, plus unused imports. |
| `camera/CameraController.kt` | Removed a no-op `preview.surfaceProvider.let { ... }` line. |
| `res/mipmap-anydpi/ic_launcher.xml` | Added. The manifest referenced `@mipmap/ic_launcher`, but only the API-26 adaptive icon existed — resource linking would fail on `minSdk 24`. This vector is the pre-26 fallback. |
⚙

`gradle/wrapper/gradle-wrapper.properties` was also added, pinning Gradle **8.9** (AGP 8.7.3's required version). The binary `gradle-wrapper.jar` is still absent — see Path 2, step 2.

---

## Which APK do I need?

| File ↕▾ | Installs on a phone? ↕▾ | Can be published? ↕▾ |
|---|---|---|
| −`app-debug.apk` (this workflow) | **Yes** | No — signed with a debug key |
| `app-release.apk` (needs a keystore) | Yes, once signed | Yes |
⚙

For personal use, sharing with testers, or sideloading, **the debug APK is exactly what you want**. It's already signed and zipaligned.

For a store release, see the "Making a release APK you can share" section of the research report: create a keystore with `keytool`, add a `signingConfigs` block to `app/build.gradle.kts`, then run `./gradlew assembleRelease`.