package com.miragedetect.camera

import android.content.Context
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Wraps CameraX lifecycle management for a single [PreviewView].
 *
 * Bind/unbind is deterministic and idempotent so configuration changes and
 * back navigation never leak a camera session.
 *
 * Frames are delivered via [onFrame] on a single-thread executor; the caller
 * is responsible for closing each [ImageProxy].
 */
class CameraController(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val onFrame: (ImageProxy) -> Unit,
) {
    private var previewView: PreviewView? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var imageAnalysis: ImageAnalysis? = null
    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    @Volatile
    private var disposed = false

    fun attach(view: PreviewView) {
        previewView = view
        start()
    }

    private fun start() {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            if (disposed) return@addListener
            try {
                val provider = future.get()
                cameraProvider = provider

                val preview = Preview.Builder().build()

                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                    .also { a ->
                        a.setAnalyzer(analysisExecutor) { proxy -> onFrame(proxy) }
                    }
                imageAnalysis = analysis

                provider.unbindAll()
                provider.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    analysis,
                )

                previewView?.let { view ->
                    preview.setSurfaceProvider(view.surfaceProvider)
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Camera start failed", t)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun shutdown() {
        disposed = true
        runCatching { imageAnalysis?.clearAnalyzer() }
        runCatching { cameraProvider?.unbindAll() }
        runCatching { analysisExecutor.shutdown() }
        imageAnalysis = null
        cameraProvider = null
        previewView = null
    }

    private companion object {
        const val TAG = "CameraController"
    }
}
